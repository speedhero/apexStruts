# 只言片语 -- 静态导航主页

采用HTML+CSS+JQ开发的最简单的静态页面，搭配github pages或者是coding pages食用效果最佳！

JS放在keyword.js中，HTML+CSS太过简单，需要者自行修改即可！
